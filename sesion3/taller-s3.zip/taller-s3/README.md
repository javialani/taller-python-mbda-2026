# Taller de Python · Sesión 3

1. Instala uv (una sola vez): ver instrucciones en clase o en el correo.
2. Abre esta carpeta en VS Code: Archivo → Abrir carpeta.
3. En la terminal de VS Code: `uv sync`
4. Abre `notebooks/00_comprobar_entorno.ipynb`, elige el kernel `.venv` y ejecuta la celda.

¿Necesitas otra librería para tu proyecto? `uv add nombre` (por ejemplo, `uv add plotly`).
¿No funciona tras 10 minutos? Sigue en Google Colab con los notebooks de Drive.
